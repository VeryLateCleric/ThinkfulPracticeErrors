### Execution Environment

The code for this project is ran using Node 10, with Mocha as the test framework.

### Customization

You are not able to customize the environment any further than what comes already pre-loaded.
